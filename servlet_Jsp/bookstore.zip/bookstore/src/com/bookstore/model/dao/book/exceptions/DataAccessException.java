package com.bookstore.model.dao.book.exceptions;

public class DataAccessException extends RuntimeException{

	public DataAccessException(String message) {
		super(message);
	}

}
